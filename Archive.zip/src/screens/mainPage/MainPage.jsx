import React, { useEffect, useState } from 'react';
import './MainPage.css';

import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min.js';


import db from './firebaseConfig';
import { collection, doc, getDoc } from "firebase/firestore";

function MainPage() {
  const [backgroundImage, setBackgroundImage] = useState('');
  const [carouselItems, setCarouselItems] = useState([
    { id: 1, name: 'Producto 1', description: 'Descripción del producto 1' },
    { id: 2, name: 'Producto 2', description: 'Descripción del producto 2' },
    { id: 3, name: 'Producto 3', description: 'Descripción del producto 3' },
    { id: 4, name: 'Producto 4', description: 'Descripción del producto 4' },
    { id: 5, name: 'Producto 5', description: 'Descripción del producto 5' },
    { id: 6, name: 'Producto 6', description: 'Descripción del producto 6' },
  ]);

  useEffect(() => {
    const fetchBackgroundImage = async () => {
      const docRef = doc(collection(db, 'images'), 'backgroundImages');
      const docSnap = await getDoc(docRef);

      if (docSnap.exists()) {
        setBackgroundImage(docSnap.data().url);
      } else {
        console.log("No such document!");
      }
    };

    const fetchProductImages = async () => {
      const docRef = doc(collection(db, 'images'), 'productImages');
      const docSnap = await getDoc(docRef);

      if (docSnap.exists()) {
        const images = docSnap.data();
        setCarouselItems(prevItems => prevItems.map((item, index) => {
          return { ...item, image: images[`image${index + 1}`] };
        }));
      } else {
        console.log("No such document!");
      }
    };

    fetchBackgroundImage().catch(error => {
      console.log("Error getting document:", error);
    });
    fetchProductImages().catch(error => {
      console.log("Error getting document:", error);
    });
  }, []);

  const carouselStyle = {
    backgroundImage: `url(${backgroundImage})`,
    backgroundRepeat: 'no-repeat',
    backgroundSize: 'cover',
    height: '100vh'
  };

  return (
    <main>
      <div>
        <div id="myCarousel" className="carousel slide" data-bs-ride="carousel" data-bs-interval="10000" style={carouselStyle}>
          <div className="carousel-indicators">
            {carouselItems.map((image, index) => (
              <button
                key={index}
                type="button"
                data-bs-target="#myCarousel"
                data-bs-slide-to={index}
                className={index === 0 ? 'active' : ''}
                aria-current={index === 0 ? 'true' : 'false'}
                aria-label={`Slide ${index + 1}`}
              ></button>
            ))}
          </div>
          <div className="carousel-inner">
            {carouselItems.map((item, index) => (
              <div key={item.id} className={`carousel-item ${index === 0 ? 'active' : ''}`}>
                <div className="d-flex align-items-center justify-content-center h-100">
                  <div className="text-center">
                    <h2>{item.name}</h2>
                    <p>{item.description}</p>
                  </div>
                  <img src={item.image} alt={item.name} />
                </div>
              </div>
            ))}
          </div>
          <button className="carousel-control-prev d-none d-sm-block" type="button" data-bs-target="#myCarousel" data-bs-slide="prev">
          <span className="carousel-control-prev-icon" aria-hidden="true"></span>
          <span className="visually-hidden">Previous</span>
        </button>
        <button className="carousel-control-next d-none d-sm-block" type="button" data-bs-target="#myCarousel" data-bs-slide="next">
          <span className="carousel-control-next-icon" aria-hidden="true"></span>
          <span className="visually-hidden">Next</span>
        </button>
        </div>
      </div>
    </main>
  );
}

export default MainPage;