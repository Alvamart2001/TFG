import React, { useState } from 'react';
import './Navbar.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import LogoAS from '/img/logo.png';

import { Link } from 'react-router-dom';

function Navbar() {
  const [isOpen, setIsOpen] = useState(false);

  const toggleSidebar = () => {
    setIsOpen(!isOpen);
  };

  return (
    <div className="navbar-container">
      <nav className="navbar navbar-dark bg-black d-flex justify-content-between align-items-center">
        <div className="d-flex align-items-center">
          <button className="navbar-toggler" type="button" onClick={toggleSidebar}>
            <span className="navbar-toggler-icon"></span>
          </button>
          <Link className="navbar-brand d-flex align-items-center ms-2" to="/">
            <img src={LogoAS} alt="Logo" className="logo img-fluid" />
          </Link>
        </div>
        
        <form className="d-flex search-form flex-grow-1 mx-3">
          <input className="form-control me-2 flex-grow-1" type="search" placeholder="Buscar producto..." aria-label="Search" />
        </form>
        
        <div className="d-flex align-items-center">
          <a className="nav-link" href="#">Ayuda</a>
          <a className="nav-link" href="#">Cesta</a>
          <a className="nav-link" href="#">Perfil</a>
        </div>
      </nav>
      
      <div className={`sidebar ${isOpen ? 'open' : ''}`}>
        <button className="close-btn" onClick={toggleSidebar}>×</button>
        <ul className="sidebar-menu">
          <li><Link to="/alimentacion-saludable">Alimentación Saludable</Link></li>
          <li><a href="#">Nutrición Deportiva</a></li>
          <li><a href="#">Salud y adelgazamiento</a></li>
          <li><a href="#">Cosmética y Cuidado Personal</a></li>
          <li><a href="#">Ropa para Mujer</a></li>
          <li><a href="#">Ropa para Hombre</a></li>
          <li><a href="#">Tecnología y Hogar</a></li>
        </ul>
      </div>
    </div>
  );
}

export default Navbar;