import React from 'react';

import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min.js';

function alimentacionSaludable() {

  return (
    <div>hola</div>
  );
}

export default alimentacionSaludable;